package com.example.ahmed.todo;

import android.widget.DatePicker;
import android.widget.TimePicker;

import java.io.Serializable;


public class Task implements Serializable {

    private String taskDetails,priority,taskDate,taskTime;

    public Task(String taskDetails, String priority, String taskDate, String taskTime) {
        this.taskDetails = taskDetails;
        this.priority = priority;
        this.taskDate = taskDate;
        this.taskTime = taskTime;
    }

    public String getTaskDetails() {
        return taskDetails;
    }

    public void setTaskDetails(String taskDetails) {
        this.taskDetails = taskDetails;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getTaskDate() {
        return taskDate;
    }

    public void setTaskDate(String taskDate) {
        this.taskDate = taskDate;
    }

    public String getTaskTime() {
        return taskTime;
    }

    public void setTaskTime(String taskTime) {
        this.taskTime = taskTime;
    }
}
